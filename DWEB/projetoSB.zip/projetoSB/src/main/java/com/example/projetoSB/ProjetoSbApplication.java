package com.example.projetoSB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoSbApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoSbApplication.class, args);
	}

}
